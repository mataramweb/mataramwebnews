<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tour extends CI_Controller {

	function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Jakarta');

		$this->load->model('m_data');

		// cek session yang login, 
		// jika session status tidak sama dengan session telah_login, berarti pengguna belum login
		// maka halaman akan di alihkan kembali ke halaman login.
		if($this->session->userdata('status')!="telah_login"){
			redirect(base_url().'login?alert=belum_login');
		}
	}

	public function index()
	{
		$data['tour'] = $this->db->query("SELECT * FROM tour,kategoritour,pengguna WHERE tour_kategori=kategoritour_id and tour_author=pengguna_id order by tour_id desc")->result();	

		$this->load->view('dashboard/v_header');
		$this->load->view('tour/v_index',$data);
		$this->load->view('dashboard/v_footer');
	}

	public function tambah()

	{
		
		$data['tour'] = $this->db->query("SELECT * FROM tour,kategoritour,pengguna WHERE tour_kategori=kategoritour_id and tour_author=pengguna_id order by tour_id desc")->result();	

		$this->load->view('dashboard/v_header');
		$this->load->view('dashboard/v_tour_tambah',$data);
		$this->load->view('dashboard/v_footer');
	}

	public function tour_aksi()
	{
		// Wajib isi judul,konten dan kategoritour
		$this->form_validation->set_rules('judul','Judul','required|is_unique[tour.tour_judul]');
		$this->form_validation->set_rules('konten','Konten','required');
		$this->form_validation->set_rules('kategoritour','kategoritour','required');

		// Membuat gambar wajib di isi
		if (empty($_FILES['sampul']['name'])){
			$this->form_validation->set_rules('sampul', 'Gambar Sampul', 'required');
		}

		if($this->form_validation->run() != false){

			$config['upload_path']   = './gambar/artikel/';
			$config['allowed_types'] = 'gif|jpg|png';

			$this->load->library('upload', $config);

			if ($this->upload->do_upload('sampul')) {

				// mengambil data tentang gambar
				$gambar = $this->upload->data();

				$tanggal = date('Y-m-d H:i:s');
				$judul = $this->input->post('judul');
				$slug = strtolower(url_title($judul));
				$konten = $this->input->post('konten');
				$sampul = $gambar['file_name'];
				$author = $this->session->userdata('id');
				$kategoritour = $this->input->post('kategoritour');
				$status = $this->input->post('status');

				$data = array(
					'tour_tanggal' => $tanggal,
					'tour_judul' => $judul,
					'tour_slug' => $slug,
					'tour_konten' => $konten,
					'tour_sampul' => $sampul,
					'tour_author' => $author,
					'tour_kategoritour' => $kategoritour,
					'tour_status' => $status,
				);

				$this->m_data->insert_data($data,'tour');

				redirect(base_url().'dashboard/Tour/index');	
				
			} else {

				$this->form_validation->set_message('sampul', $data['gambar_error'] = $this->upload->display_errors());

				$data['kategoritour'] = $this->m_data->get_data('kategoritour')->result();
				$this->load->view('dashboard/v_header');
				$this->load->view('dashboard/Tour/v_tour_tambah',$data);
				$this->load->view('dashboard/v_footer');
			}

		}else{
			$data['kategoritour'] = $this->m_data->get_data('kategoritour')->result();
			$this->load->view('dashboard/v_header');
			$this->load->view('dashboard/Tour/v_tour_tambah',$data);
			$this->load->view('dashboard/v_footer');
		}
	}


	public function edit($id)
	{
		$where = array(
			'tour_id' => $id
		);
		$data['tour'] = $this->m_data->edit_data($where,'tour')->result();
		$data['kategoritour'] = $this->m_data->get_data('kategoritour')->result();
		$this->load->view('dashboard/v_header');
		$this->load->view('tour/v_tour_edit',$data);
		$this->load->view('dashboard/v_footer');
	}


	public function tour_update()
	{
		// Wajib isi judul,konten dan kategoritour
		$this->form_validation->set_rules('judul','Judul','required');
		$this->form_validation->set_rules('konten','Konten','required');
		$this->form_validation->set_rules('kategoritour','kategoritour','required');
		
		if($this->form_validation->run() != false){

			$id = $this->input->post('id');

			$judul = $this->input->post('judul');
			$slug = strtolower(url_title($judul));
			$konten = $this->input->post('konten');
			$kategoritour = $this->input->post('kategoritour');
			$status = $this->input->post('status');

			$where = array(
				'tour_id' => $id
			);

			$data = array(
				'tour_judul' => $judul,
				'tour_slug' => $slug,
				'tour_konten' => $konten,
				'tour_kategoritour' => $kategoritour,
				'tour_status' => $status,
			);

			$this->m_data->update_data($where,$data,'tour');


			if (!empty($_FILES['sampul']['name'])){
				$config['upload_path']   = './gambar/tour/';
				$config['allowed_types'] = 'gif|jpg|png';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload('sampul')) {

					// mengambil data tentang gambar
					$gambar = $this->upload->data();

					$data = array(
						'tour_sampul' => $gambar['file_name'],
					);

					$this->m_data->update_data($where,$data,'tour');

					redirect(base_url().'dashboard/Tour/tour_list');	

				} else {
					$this->form_validation->set_message('sampul', $data['gambar_error'] = $this->upload->display_errors());
					
					$where = array(
						'tour_id' => $id
					);
					$data['tour'] = $this->m_data->edit_data($where,'tour')->result();
					$data['kategoritour'] = $this->m_data->get_data('kategoritour')->result();
					$this->load->view('dashboard/v_header');
					$this->load->view('dashboard/Tour/v_tour_edit',$data);
					$this->load->view('dashboard/v_footer');
				}
			}else{
				redirect(base_url().'Tour/tour_list');	
			}

		}else{
			$id = $this->input->post('id');
			$where = array(
				'tour_id' => $id
			);
			$data['tour'] = $this->m_data->edit_data($where,'tour')->result();
			$data['kategoritour'] = $this->m_data->get_data('kategoritour')->result();
			$this->load->view('dashboard/v_header');
			$this->load->view('dashboard/Tour/v_tour_edit',$data);
			$this->load->view('dashboard/v_footer');
		}
	}



	
}
