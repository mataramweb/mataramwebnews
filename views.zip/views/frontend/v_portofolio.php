
<div class="intro intro-single route bg-image" style="background-image: url(img/overlay-bg.jpg)">
  <div class="overlay-mf"></div>
  <div class="intro-content display-table">
    <div class="table-cell">
      <div class="container">
        <h2 class="intro-title mb-4">Portofolio</h2>
        <ol class="breadcrumb d-flex justify-content-center">
          <li class="breadcrumb-item">
            <a href="<?php echo base_url(); ?>">Home</a>
          </li>
          <li class="breadcrumb-item">
            <a href="<?php echo base_url('portofolio'); ?>">Portofolio</a>
          </li>
          <li class="breadcrumb-item active">Portofolio</li>
        </ol>
      </div>
    </div>
  </div>
</div>
<!--/ Intro Skew End /-->




    <!--/ Section Portfolio Star /-->
    <section id="work" class="portfolio-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              Portfolio
            </h3>
            <p class="subtitle-a">
              Berikut adalah hasil kerja kami.
            </p>
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
      <?php foreach($portofolio as $a){ ?>

        <div class="col-md-4">
          <div class="work-box">
            <a href="<?php echo base_url() ?>assets_frontend/img/work-1.jpg" data-lightbox="gallery-mf">
              <div class="work-img">
              <?php if($a->portofolio_sampul != ""){ ?>     <img src="<?php echo base_url(); ?>gambar/portofolio/<?php echo $a->portofolio_sampul ?>" alt="<?php echo $a->portofolio_nama ?>" class="img-fluid">

                <?php } ?>
              </div>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title"><a href="<?php echo base_url().$a->portofolio_slug ?>"><?php echo $a->portofolio_nama ?></h2>
                    <div class="w-more">
                      <span class="w-ctegory">Web Design</span> / <span class="w-date">18 Sep. 2018</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            </a>
            
          </div>

        </div>
        <?php } ?>     
      </div>

    </div>



  </section>
       
  <!--/ Section Portfolio End /-->