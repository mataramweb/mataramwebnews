<div class="traveltour-page-wrapper" id="traveltour-page-wrapper">
                <div class="tourmaster-page-wrapper tourmaster-tour-style-1 tourmaster-with-sidebar" id="tourmaster-page-wrapper" style="min-height: 937px;">
                <?php foreach($tour as $a){ ?>
                    <div class="tourmaster-single-header" id="div_ffaa_0">
                        <div class="tourmaster-single-header-background-overlay"></div>
                        <div class="tourmaster-single-header-top-overlay"></div>
                        <div class="tourmaster-single-header-overlay"></div>
                        <div class="tourmaster-single-header-container tourmaster-container">
                            <div class="tourmaster-single-header-container-inner">
                                <div class="tourmaster-single-header-title-wrap tourmaster-item-pdlr">
                                    <h1 class="tourmaster-single-header-title"><?php echo $a->tour_judul ?></h1>
                                    <div class="tourmaster-tour-rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><span class="tourmaster-tour-rating-text">(1 Review)</span></div>
                                </div>
                                <div class="tourmaster-header-price tourmaster-item-mglr">
                                    <div class="tourmaster-header-price-ribbon">Price</div>
                                    <div class="tourmaster-header-price-wrap">
                                        <div class="tourmaster-header-price-overlay"></div>
                                        <div class="tourmaster-tour-price-wrap "><span class="tourmaster-tour-price"><span class="tourmaster-head">From</span><span class="tourmaster-tail">$300</span></span><span class="fa fa-info-circle tourmaster-tour-price-info" data-rel="tipsy" original-title="The initial price based on 1 adult with the lowest price in low season"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tourmaster-template-wrapper">
                        <div class="tourmaster-tour-booking-bar-container tourmaster-container">
                            <div class="tourmaster-tour-booking-bar-container-inner">
                                <div class="tourmaster-tour-booking-bar-anchor tourmaster-item-mglr" style="margin-top: -178px;"></div>
                                <div class="tourmaster-tour-booking-bar-wrap tourmaster-item-mglr tourmaster-start-script" id="tourmaster-tour-booking-bar-wrap" style="margin-top: -178px;">
                                    <div class="tourmaster-tour-booking-bar-outer">
                                        <div class="tourmaster-header-price tourmaster-item-mglr">
                                            <div class="tourmaster-header-price-ribbon">Price</div>
                                            <div class="tourmaster-header-price-wrap">
                                                <div class="tourmaster-header-price-overlay"></div>
                                                <div class="tourmaster-tour-price-wrap "><span class="tourmaster-tour-price"><span class="tourmaster-head">From</span><span class="tourmaster-tail">$300</span></span><span class="fa fa-info-circle tourmaster-tour-price-info" data-rel="tipsy" original-title="The initial price based on 1 adult with the lowest price in low season"></span></div>
                                            </div>
                                        </div>
                                        <div class="tourmaster-tour-booking-bar-inner">
                                            <div class="tourmaster-booking-tab-title clearfix" id="tourmaster-booking-tab-title">
                                                <div class="tourmaster-booking-tab-title-item tourmaster-active" data-tourmaster-tab="booking">Booking Form</div>
                                                <div class="tourmaster-booking-tab-title-item" data-tourmaster-tab="enquiry">Enquiry Form</div>
                                            </div>
                                            <div class="tourmaster-booking-tab-content" data-tourmaster-tab="enquiry">
                                                <div class="tourmaster-tour-booking-enquiry-wrap">
                                                    <form class="tourmaster-enquiry-form tourmaster-form-field tourmaster-with-border clearfix" id="tourmaster-enquiry-form" data-action="tourmaster_send_enquiry_form" data-validate-error="Please fill all required fields.">
                                                        <div class="tourmaster-enquiry-field tourmaster-enquiry-field-full-name tourmaster-type-text clearfix">
                                                            <div class="tourmaster-head">Full Name<span class="tourmaster-req">*</span></div>
                                                            <div class="tourmaster-tail clearfix">
                                                                <input type="text" name="full-name" value="" data-required="">
                                                            </div>
                                                        </div>
                                                        <div class="tourmaster-enquiry-field tourmaster-enquiry-field-email-address tourmaster-type-email clearfix">
                                                            <div class="tourmaster-head">Email Address<span class="tourmaster-req">*</span></div>
                                                            <div class="tourmaster-tail clearfix">
                                                                <input type="email" name="email-address" value="" data-required="">
                                                            </div>
                                                        </div>
                                                        <div class="tourmaster-enquiry-field tourmaster-enquiry-field-travel-date tourmaster-type-datepicker clearfix">
                                                            <div class="tourmaster-head">Travel Date<span class="tourmaster-req">*</span></div>
                                                            <div class="tourmaster-tail clearfix">
                                                                <input type="text" class="tourmaster-datepicker hasDatepicker" name="travel-date" value="" id="dp1587229995783"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                        <div class="tourmaster-enquiry-field tourmaster-enquiry-field-person tourmaster-type-combobox clearfix">
                                                            <div class="tourmaster-head">Person<span class="tourmaster-req">*</span></div>
                                                            <div class="tourmaster-tail clearfix">
                                                                <div class="tourmaster-combobox-wrap">
                                                                    <select name="person" data-required="">
                                                                        <option value="Person">Person</option>
                                                                        <option value="1-4">1-4</option>
                                                                        <option value="5-9">5-9</option>
                                                                        <option value="10+">10+</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tourmaster-enquiry-field tourmaster-enquiry-field-your-enquiry tourmaster-type-textarea clearfix">
                                                            <div class="tourmaster-head">Your Enquiry<span class="tourmaster-req">*</span></div>
                                                            <div class="tourmaster-tail clearfix">
                                                                <textarea name="your-enquiry" data-required=""></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="tourmaster-enquiry-form-message"></div>
                                                        <input type="hidden" name="tour-id" value="4643">
                                                        <input type="submit" class="tourmaster-button" value="Submit Enquiry">
                                                    </form>
                                                </div>
                                            </div>
                                            <div class="tourmaster-booking-tab-content tourmaster-active" data-tourmaster-tab="booking">
                                                <form class="tourmaster-single-tour-booking-fields tourmaster-update-header-price tourmaster-form-field tourmaster-with-border" method="post" action="https://demo.goodlayers.com/traveltour/?tourmaster-payment" id="tourmaster-single-tour-booking-fields">
                                                    <input type="hidden" name="tour-id" value="4643">
                                                    <div class="tourmaster-tour-booking-date clearfix" data-step="1"><i class="fa fa-calendar"></i>
                                                        <div class="tourmaster-tour-booking-date-input">
                                                            <div class="tourmaster-tour-booking-date-display">February 5, 2022</div>
                                                            <input type="hidden" name="tour-date" value="2022-02-05">
                                                        </div>
                                                    </div>
                                                    <div class="tourmaster-tour-booking-package" data-step="2">
                                                        <div class="tourmaster-tour-booking-next-sign"><span></span></div><i class="icon_check"></i>
                                                        <div class="tourmaster-combobox-list-wrap">
                                                            <div class="tourmaster-combobox-list-display"><span>Select a package</span></div>
                                                            <input type="hidden" name="package" value="">
                                                            <ul>
                                                                <li data-value="Standard" class=""><span class="tourmaster-combobox-list-title">Standard</span><span class="tourmaster-combobox-list-caption">No food, no entry tickets</span><span class="tourmaster-combobox-list-time">Start Time: 12:00</span><span class="tourmaster-combobox-list-avail">Available: -4 seats</span></li>
                                                                <li data-value="Special Package" class=""><span class="tourmaster-combobox-list-title">Special Package</span><span class="tourmaster-combobox-list-caption">With food &amp; entry tickets</span><span class="tourmaster-combobox-list-time">Start Time: 12:00</span><span class="tourmaster-combobox-list-avail">Available: -4 seats</span></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </form>
                                                <div class="tourmaster-lightbox-content-wrap" data-tmlb-id="proceed-without-login">
                                                    <div class="tourmaster-lightbox-head">
                                                        <h3 class="tourmaster-lightbox-title">Proceed Booking</h3><i class="tourmaster-lightbox-close icon_close"></i></div>
                                                    <div class="tourmaster-lightbox-content">
                                                        <div class="tourmaster-login-form2-wrap clearfix">
                                                           
                                                            <div class="tourmaster-login2-right">
                                                                <h3 class="tourmaster-login2-right-title">Don't have an account? Create one.</h3>
                                                                <div class="tourmaster-login2-right-content">
                                                                    <div class="tourmaster-login2-right-description">When you book with an account, you will be able to track your payment status, track the confirmation and you can also rate the tour after you finished the tour.</div> <a class="tourmaster-button" href="../../register/indexbd2a.html?redirect=payment">Sign Up</a></div>
                                                                <h3 class="tourmaster-login2-right-title">Or Continue As Guest</h3> <a class="tourmaster-button" href="../../index4bb8.html?tourmaster-payment">Continue As Guest</a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="tourmaster-tour-booking-bar-widget  traveltour-sidebar-area">
                                        <div id="text-11" class="widget widget_text traveltour-widget">
                                            <div class="textwidget"><span class="gdlr-core-space-shortcode" id="span_ffaa_0"></span>
                                                <div class="gdlr-core-widget-list-shortcode" id="gdlr-core-widget-list-0">
                                                    <h3 class="gdlr-core-widget-list-shortcode-title">Why Book With Us?</h3>
                                                    <ul>
                                                        <li><i class="fa fa-dollar" id="i_ffaa_4"></i>No-hassle best price guarantee</li>
                                                        <li><i class="fa fa-headphones" id="i_ffaa_5"></i>Customer care available 24/7</li>
                                                        <li><i class="fa fa-star" id="i_ffaa_6"></i>Hand-picked Tours &amp; Activities</li>
                                                        <li><i class="fa fa-support" id="i_ffaa_7"></i>Free Travel Insureance</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="text-12" class="widget widget_text traveltour-widget">
                                            <div class="textwidget"><span class="gdlr-core-space-shortcode" id="span_ffaa_1"></span>
                                                <div class="gdlr-core-widget-box-shortcode " id="div_ffaa_1">
                                                    <h3 class="gdlr-core-widget-box-shortcode-title" id="h3_ffaa_0">Get a Question?</h3>
                                                    <div class="gdlr-core-widget-box-shortcode-content">
                                                        <p>Do not hesitage to give us a call. We are an expert team and we are happy to talk to you.</p>
                                                        <p><i class="fa fa-phone" id="i_ffaa_8"></i> <span id="span_ffaa_2">1.8445.3356.33</span></p>
                                                        <p><i class="fa fa-envelope-o" id="i_ffaa_9"></i> <span id="span_ffaa_3">Help@goodlayers.com</span></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tourmaster-tour-info-outer">
                            <div class="tourmaster-tour-info-outer-container tourmaster-container">
                                <div class="tourmaster-tour-info-wrap clearfix">
                                    <div class="tourmaster-tour-info tourmaster-tour-info-duration-text tourmaster-item-pdlr"><i class="icon_clock_alt"></i> <?php echo $a->tour_durasi ?></div>
                                    <div class="tourmaster-tour-info tourmaster-tour-info-availability tourmaster-item-pdlr"><i class="fa fa-calendar"></i></div>
           
                                </div>
                            </div>
                        </div>

                                                <?php } ?>

                        <div class="gdlr-core-page-builder-body">
                            <div class="gdlr-core-pbf-wrapper " id="div_ffaa_2">
                                <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                                    <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-pbf-wrapper-full">
                                        <div class="gdlr-core-pbf-element">
                                            <div class="tourmaster-content-navigation-item-wrap clearfix" id="div_ffaa_3" style="height: auto;">
                                                <div class="tourmaster-content-navigation-item-outer" id="tourmaster-content-navigation-item-outer">
                                                    <div class="tourmaster-content-navigation-item-container tourmaster-container">
                                                        <div class="tourmaster-content-navigation-item tourmaster-item-pdlr"><a class="tourmaster-content-navigation-tab tourmaster-active tourmaster-slidebar-active" href="#detail" data-anchor="#detail">Detail</a><a class="tourmaster-content-navigation-tab" href="#itinerary" data-anchor="#itinerary">Itinerary</a><a class="tourmaster-content-navigation-tab" href="#map" data-anchor="#map">Map</a><a class="tourmaster-content-navigation-tab" href="#photos" data-anchor="#photos">Photos</a><a class="tourmaster-content-navigation-tab" href="#tourmaster-single-review" data-anchor="#tourmaster-single-review">Reviews</a>
                                                            <div class="tourmaster-content-navigation-slider" style="width: 91px; left: 20px; overflow: hidden;"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="gdlr-core-pbf-wrapper " data-skin="Blue Icon" id="detail">
                                <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                                    <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                        <div class="gdlr-core-pbf-element">
                                            <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-bottom gdlr-core-item-pdlr" id="div_ffaa_4">
                                                <div class="gdlr-core-title-item-title-wrap">
                                                    <h6 class="gdlr-core-title-item-title gdlr-core-skin-title" id="h6_ffaa_0"><span class="gdlr-core-title-item-left-icon" id="span_ffaa_4"><i class="fa fa-file-text-o"></i></span>Tour Details<span class="gdlr-core-title-item-title-divider gdlr-core-skin-divider"></span></h6></div>
                                            </div>
                                        </div>
                                        <div class="gdlr-core-pbf-element">
                                            <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align">
                                                <div class="gdlr-core-text-box-item-content">
                                                <?php echo $a->tour_konten ?>
                                                </div>
                                            </div>
                                        </div>
                       
                      
                        
   
         

                              
                                        <div class="gdlr-core-pbf-element">
                                            <div class="gdlr-core-divider-item gdlr-core-item-pdlr gdlr-core-item-mgb gdlr-core-divider-item-normal gdlr-core-center-align" id="div_ffaa_17">
                                                <div class="gdlr-core-divider-line gdlr-core-skin-divider"></div>
                                            </div>
                                        </div>
                                        <div class="gdlr-core-pbf-column gdlr-core-column-30 gdlr-core-column-first">
                                            <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                                <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                                    <div class="gdlr-core-pbf-element">
                                                        <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" id="div_ffaa_18">
                                                            <div class="gdlr-core-title-item-title-wrap">
                                                                <h3 class="gdlr-core-title-item-title gdlr-core-skin-title" id="h3_ffaa_5">Tinggalkan Komentar <span class="gdlr-core-title-item-title-divider gdlr-core-skin-divider"></span></h3></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="gdlr-core-pbf-element">
                                            <div class="gdlr-core-divider-item gdlr-core-item-pdlr gdlr-core-item-mgb gdlr-core-divider-item-normal gdlr-core-center-align" id="div_ffaa_20">
                                                <div class="gdlr-core-divider-line gdlr-core-skin-divider"><?php echo $disqus ?></div>
                                            </div>
                                        </div>


                                        
           
                                        <div class="gdlr-core-pbf-element">
                                            <div class="gdlr-core-divider-item gdlr-core-item-pdlr gdlr-core-item-mgb gdlr-core-divider-item-normal gdlr-core-center-align" id="div_ffaa_20">
                                                <div class="gdlr-core-divider-line gdlr-core-skin-divider"></div>
                                            </div>
                                        </div>
                                        <div class="gdlr-core-pbf-element">
                                            <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-bottom gdlr-core-item-pdlr">
                                                <div class="gdlr-core-title-item-title-wrap">
                                                    <h6 class="gdlr-core-title-item-title gdlr-core-skin-title" id="h6_ffaa_1">What to Expect<span class="gdlr-core-title-item-title-divider gdlr-core-skin-divider"></span></h6></div>
                                            </div>
                                        </div>
                                        <div class="gdlr-core-pbf-element">
                                            <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" id="div_ffaa_21">
                                                <div class="gdlr-core-text-box-item-content">
                                                    <p>Curabitur blandit tempus porttitor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras mattis consectetur purus sit amet fermentum. Etiam porta sem malesuada magna mollis euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                                    <p>Maecenas sed diam eget risus varius blandit sit amet non magna. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Nullam id dolor id nibh ultricies vehicula ut id elit. Donec ullamcorper nulla non metus auctor fringilla.</p>
                                                </div>
                                            </div>
                                        </div>
                      
                                        <div class="gdlr-core-pbf-element">
                                            <div class="gdlr-core-divider-item gdlr-core-item-pdlr gdlr-core-item-mgb gdlr-core-divider-item-normal gdlr-core-center-align" id="div_ffaa_22">
                                                <div class="gdlr-core-divider-line gdlr-core-skin-divider"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
    
                        </div>
                        <div class="tourmaster-single-related-tour tourmaster-tour-item tourmaster-style-grid">
                            <div class="tourmaster-single-related-tour-container tourmaster-container">
                                <h3 class="tourmaster-single-related-tour-title tourmaster-item-pdlr">Related Tours</h3>
                                <div class="tourmaster-tour-item-holder clearfix ">
                                    <div class="gdlr-core-item-list  tourmaster-column-30 tourmaster-item-pdlr tourmaster-column-first">
                                        <div class="tourmaster-tour-grid  tourmaster-price-right-title">
                                            <div class="tourmaster-tour-thumbnail tourmaster-media-image">
                                                <a href="../africa-amazing-african-safari/index.html"><img src="upload/shutterstock_120562819-1024x683.jpg" alt="" width="1024" height="683"></a>
                                            </div>
                                            <div class="tourmaster-tour-content-wrap gdlr-core-skin-e-background">
                                                <h3 class="tourmaster-tour-title gdlr-core-skin-title"><a href="../africa-amazing-african-safari/index.html">Africa – Amazing African Safari</a></h3>
                                                <div class="tourmaster-tour-price-wrap "><span class="tourmaster-tour-price"><span class="tourmaster-head">From</span><span class="tourmaster-tail">$100</span></span>
                                                </div>
                                                <div class="tourmaster-tour-rating tourmaster-tour-rating-empty">0</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gdlr-core-item-list  tourmaster-column-30 tourmaster-item-pdlr">
                                        <div class="tourmaster-tour-grid  tourmaster-price-right-title">
                                            <div class="tourmaster-tour-thumbnail tourmaster-media-image">
                                                <a href="../dubai-all-stunning-places/index.html"><img src="upload/shutterstock_151616084-1024x683.jpg" alt="" width="1024" height="683"></a>
                                            </div>
                                            <div class="tourmaster-tour-content-wrap gdlr-core-skin-e-background">
                                                <h3 class="tourmaster-tour-title gdlr-core-skin-title"><a href="../dubai-all-stunning-places/index.html">Dubai – All Stunning Places</a></h3>
                                                <div class="tourmaster-tour-price-wrap "><span class="tourmaster-tour-price"><span class="tourmaster-head">From</span><span class="tourmaster-tail">$1,200</span></span>
                                                </div>
                                                <div class="tourmaster-tour-rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><span class="tourmaster-tour-rating-text">(2 Reviews)</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
              
                    </div>
                </div>
                <div class="tourmaster-urgency-message" id="tourmaster-urgency-message" data-expire="86400"><i class="tourmaster-urgency-message-icon fa fa-users"></i>
                    <div class="tourmaster-urgency-message-text">6 travellers are considering this tour right now!</div>
                </div>
            </div>
      
