


            

            <div class="traveltour-page-wrapper" id="traveltour-page-wrapper">
                <div class="gdlr-core-page-builder-body">
                    <div class="gdlr-core-pbf-wrapper  gdlr-core-hide-in-mobile" id="div_aeb3_0" data-skin="Dark Search HP4">
                        <div class="gdlr-core-pbf-background-wrap">
                            <div class="gdlr-core-pbf-background gdlr-core-parallax gdlr-core-js" id="div_aeb3_1" data-parallax-speed="0.2"></div>
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-element">
                                    <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" id="div_aeb3_2">
                                        <div class="gdlr-core-title-item-title-wrap">
                                            <h3 class="gdlr-core-title-item-title gdlr-core-skin-title" id="h3_aeb3_0"><span class="gdlr-core-title-item-left-icon" id="span_aeb3_0"  ><i class="icon_search"  ></i></span>Search Tours<span class="gdlr-core-title-item-title-divider gdlr-core-skin-divider" ></span></h3></div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-element">
                                    <div class="tourmaster-tour-search-item clearfix tourmaster-style-column tourmaster-column-count-6 tourmaster-item-pdlr">
                                        <div class="tourmaster-tour-search-wrap ">
                                            <form class="tourmaster-form-field tourmaster-with-border" action="https://demo.goodlayers.com/travelsearch-tours/" method="GET">
                                                <div class="tourmaster-tour-search-field tourmaster-tour-search-field-keywords">
                                                    <label>Keywords</label>
                                                    <div class="tourmaster-tour-search-field-inner">
                                                        <input name="tour-search" type="text" value="" />
                                                    </div>
                                                </div>
                                                <div class="tourmaster-tour-search-field tourmaster-tour-search-field-tax">
                                                    <label>Activity</label>
                                                    <div class="tourmaster-combobox-wrap">
                                                        <select name="tour-activity">
                                                            <option value="">Any</option>
                                                            <option value="city-tours">City Tours</option>
                                                            <option value="cultural-thematic-tours">Cultural &amp; Thematic Tours</option>
                                                            <option value="family-friendly-tours">Family Friendly Tours</option>
                                                            <option value="holiday-seasonal-tours">Holiday &amp; Seasonal Tours</option>
                                                            <option value="indulgence-luxury-tours">Indulgence &amp; Luxury Tours</option>
                                                            <option value="outdoor-activites">Outdoor Activites</option>
                                                            <option value="relaxation-tours">Relaxation Tours</option>
                                                            <option value="wild-adventure-tours">Wild &amp; Adventure Tours</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="tourmaster-tour-search-field tourmaster-tour-search-field-tax">
                                                    <label>Destination</label>
                                                    <div class="tourmaster-combobox-wrap">
                                                        <select name="tour-destination">
                                                            <option value="">Any</option>
                                                            <option value="africa">Africa</option>
                                                            <option value="america">America</option>
                                                            <option value="asia">Asia</option>
                                                            <option value="eastern-europe">Eastern Europe</option>
                                                            <option value="europe">Europe</option>
                                                            <option value="south-america">South America</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="tourmaster-tour-search-field tourmaster-tour-search-field-duration">
                                                    <label>Duration</label>
                                                    <div class="tourmaster-combobox-wrap">
                                                        <select name="duration">
                                                            <option value="">Any</option>
                                                            <option value="1">1 Day Tour</option>
                                                            <option value="2">2-4 Days Tour</option>
                                                            <option value="5">5-7 Days Tour</option>
                                                            <option value="7">7+ Days Tour</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="tourmaster-tour-search-field tourmaster-tour-search-field-date">
                                                    <label>Date</label>
                                                    <div class="tourmaster-datepicker-wrap">
                                                        <input class="tourmaster-datepicker" type="text" value="" data-date-format="d M yy" />
                                                        <input class="tourmaster-datepicker-alt" name="date" type="hidden" value="" />
                                                    </div>
                                                </div>
                                                <input class="tourmaster-tour-search-submit" type="submit" value="Search" />
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gdlr-core-pbf-sidebar-wrapper ">
                        <div class="gdlr-core-pbf-sidebar-container gdlr-core-line-height-0 clearfix gdlr-core-js gdlr-core-container">
                            <div class="gdlr-core-pbf-sidebar-content  gdlr-core-column-40 gdlr-core-pbf-sidebar-padding gdlr-core-line-height gdlr-core-column-extend-left">
                                <div class="gdlr-core-pbf-background-wrap" id="div_aeb3_3"></div>
                                <div class="gdlr-core-pbf-sidebar-content-inner">
                                    <div class="gdlr-core-pbf-element">
                                        <div class="tourmaster-tour-item clearfix  tourmaster-tour-item-style-medium">
                                            <div class="tourmaster-tour-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                                               
                                            
                                            <?php foreach($tour as $a){ ?>





                                            <div class="tourmaster-item-list tourmaster-tour-medium tourmaster-item-mglr clearfix tourmaster-tour-frame gdlr-core-skin-e-background">
                                                    <div class="tourmaster-tour-medium-inner">
                                                        <div class="tourmaster-tour-thumbnail tourmaster-media-image">
                                                        <?php if($a->tour_sampul != ""){ ?>
                                                            <a href="<?php echo base_url('package/').$a->tour_slug ?>"><img src="<?php echo base_url(); ?>gambar/paket/tinggi/<?php echo $a->tour_sampul ?>" alt="<?php echo $a->tour_judul ?>" width="600" height="700" /></a>
                                                            <?php } ?>
                                                        </div>
                                                        <div class="tourmaster-tour-content-wrap clearfix">
                                                            <div class="tourmaster-content-left">
                                                                <h3 class="tourmaster-tour-title gdlr-core-skin-title" id="h3_aeb3_1"><a href="<?php echo base_url('package/').$a->tour_slug ?>" ><?php echo $a->tour_judul ?></a></a></h3>
                                                                <div class="tourmaster-tour-info-wrap clearfix">
                                                                    <div class="tourmaster-tour-info tourmaster-tour-info-duration-text "><i class="icon_clock_alt"></i><?php echo $a->tour_durasi ?></div>
         
                                                                </div>
                                                                <div class="tourmaster-tour-content">Donec id elit non mi porta gravida at eget metus. Nulla vitae elit libero, [&hellip;]</div>
                                                            </div>
                                                            <div class="tourmaster-content-right tourmaster-center-tour-content">
                                                                <div class="tourmaster-tour-price-wrap "><span class="tourmaster-tour-price"><span class="tourmaster-head">From</span><span class="tourmaster-tail"><?php echo $a->tour_harga ?></span></span>
                                                                </div>
                                                                <div class="tourmaster-tour-rating tourmaster-tour-rating-empty">0</div><a class="tourmaster-tour-view-more" href="<?php echo base_url('package/').$a->tour_slug ?>">View Details</a></div>
                                                        </div>
                                                    </div>
                                                </div>


                                                <?php } ?>








                                            </div>


                                            <div class="gdlr-core-pagination  gdlr-core-style-circle gdlr-core-left-align tourmaster-item-pdlr"><span aria-current='page' class='page-numbers current'>1</span> <a class='page-numbers' href='page/2/index.html'>2</a> <a class='page-numbers' href='page/3/index.html'>3</a> <a class='page-numbers' href='page/4/index.html'>4</a>
                                                <a class="next page-numbers" href="page/2/index.html"></a>
                                            </div>







                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="gdlr-core-pbf-sidebar-right gdlr-core-column-extend-right  traveltour-sidebar-area gdlr-core-column-20 gdlr-core-pbf-sidebar-padding  gdlr-core-line-height" id="div_aeb3_8">
                                <div class="gdlr-core-pbf-background-wrap" id="div_aeb3_9"></div>
                                <div class="gdlr-core-sidebar-item gdlr-core-item-pdlr">
                                    <div id="tourmaster-tour-widget-5" class="widget widget_tourmaster-tour-widget traveltour-widget">
                                        <h3 class="traveltour-widget-title"><span class="traveltour-widget-head-text">Latest Tours</span></h3><span class="clear"></span>
                                        <div class="tourmaster-recent-tour-widget tourmaster-tour-item">
                                            
                                            <div class="tourmaster-item-list tourmaster-tour-widget tourmaster-item-pdlr">
                                                <div class="tourmaster-tour-widget-inner clearfix">
                                                    <div class="tourmaster-tour-thumbnail tourmaster-media-image">
                                                        <a href="../africa-amazing-african-safari/index.html"><img src="upload/shutterstock_120562819-150x150.jpg" alt="" width="150" height="150" /></a>
                                                    </div>
                                                    <div class="tourmaster-tour-content-wrap">
                                                        <h3 class="tourmaster-tour-title gdlr-core-skin-title"><a href="../africa-amazing-african-safari/index.html" >Africa &#8211; Amazing African Safari</a></h3>
                                                        <div class="tourmaster-tour-content-info clearfix ">
                                                            <div class="tourmaster-tour-price-wrap "><span class="tourmaster-tour-price"><span class="tourmaster-head">From</span><span class="tourmaster-tail">$100</span></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tourmaster-item-list tourmaster-tour-widget tourmaster-item-pdlr">
                                                <div class="tourmaster-tour-widget-inner clearfix">
                                                    <div class="tourmaster-tour-thumbnail tourmaster-media-image">
                                                        <a href="../dubai-all-stunning-places/index.html"><img src="upload/shutterstock_151616084-150x150.jpg" alt="" width="150" height="150" /></a>
                                                    </div>
                                                    <div class="tourmaster-tour-content-wrap">
                                                        <h3 class="tourmaster-tour-title gdlr-core-skin-title"><a href="../dubai-all-stunning-places/index.html" >Dubai &#8211; All Stunning Places</a></h3>
                                                        <div class="tourmaster-tour-content-info clearfix ">
                                                            <div class="tourmaster-tour-price-wrap "><span class="tourmaster-tour-price"><span class="tourmaster-head">From</span><span class="tourmaster-tail">$1,200</span></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tourmaster-item-list tourmaster-tour-widget tourmaster-item-pdlr">
                                                <div class="tourmaster-tour-widget-inner clearfix">
                                                    <div class="tourmaster-tour-thumbnail tourmaster-media-image">
                                                        <a href="../switzerland-7-days-in-zurich-zermatt/index.html"><img src="upload/shutterstock_178807262-150x150.jpg" alt="" width="150" height="150" /></a>
                                                    </div>
                                                    <div class="tourmaster-tour-content-wrap">
                                                        <h3 class="tourmaster-tour-title gdlr-core-skin-title"><a href="../switzerland-7-days-in-zurich-zermatt/index.html" >Switzerland &#8211; 7 Days in Zurich, Zermatt</a></h3>
                                                        <div class="tourmaster-tour-content-info clearfix tourmaster-with-ribbon">
                                                            <div class="tourmaster-thumbnail-ribbon gdlr-core-outer-frame-element" id="div_aeb3_10">
                                                                <div class="tourmaster-thumbnail-ribbon-cornor" id="div_aeb3_11"></div>20% Off</div>
                                                            <div class="tourmaster-tour-price-wrap tourmaster-discount"><span class="tourmaster-tour-price"><span class="tourmaster-head">From</span><span class="tourmaster-tail">$4,300</span></span><span class="tourmaster-tour-discount-price">$3,500</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tourmaster-item-list tourmaster-tour-widget tourmaster-item-pdlr">
                                                <div class="tourmaster-tour-widget-inner clearfix">
                                                    <div class="tourmaster-tour-thumbnail tourmaster-media-image">
                                                        <a href="../italy-6-days-in-rome-venice-milan/index.html"><img src="upload/shutterstock_245507692-150x150.jpg" alt="" width="150" height="150" /></a>
                                                    </div>
                                                    <div class="tourmaster-tour-content-wrap">
                                                        <h3 class="tourmaster-tour-title gdlr-core-skin-title"><a href="../italy-6-days-in-rome-venice-milan/index.html" >Enquiry Form Only &#8211; Italy &#8211; 6 Days</a></h3>
                                                        <div class="tourmaster-tour-content-info clearfix tourmaster-with-ribbon">
                                                            <div class="tourmaster-thumbnail-ribbon gdlr-core-outer-frame-element" id="div_aeb3_12">
                                                                <div class="tourmaster-thumbnail-ribbon-cornor" id="div_aeb3_13"></div>25% Off</div>
                                                            <div class="tourmaster-tour-price-wrap tourmaster-discount"><span class="tourmaster-tour-price"><span class="tourmaster-head">From</span><span class="tourmaster-tail">$3,700</span></span><span class="tourmaster-tour-discount-price">$2,000</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            
                                        </div>
                                    </div>
                      
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
