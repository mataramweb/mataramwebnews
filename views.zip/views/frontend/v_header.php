<!DOCTYPE html>
<html lang="en-US" prefix="og: http://ogp.me/ns#" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="xmlrpc.php">
    <title>Homepage 1 - Travel Tour</title>

    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poppins%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2Cregular%2Citalic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7COpen+Sans%3A300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic&amp;subset=latin%2Clatin-ext%2Cdevanagari%2Ccyrillic-ext%2Cvietnamese%2Ccyrillic%2Cgreek-ext%2Cgreek&amp;ver=4.9.8' type='text/css' media='all' />
   

    <link rel='stylesheet' href='<?php echo base_url(); ?>mataramweb/plugins/revslider/public/assets/css/settings.css' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo base_url(); ?>mataramweb/plugins/tourmaster/plugins/elegant-font/style.css' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo base_url(); ?>mataramweb/plugins/tourmaster/tourmaster.css' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo base_url(); ?>mataramweb/css/tourmaster-style-custom.css' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo base_url(); ?>mataramweb/css/style-core.css' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo base_url(); ?>mataramweb/css/traveltour-style-custom.css' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo base_url(); ?>mataramweb/plugins/goodlayers-core/plugins/combine/style.css' type='text/css' media='all' />
    <link rel='stylesheet' href='<?php echo base_url(); ?>mataramweb/plugins/goodlayers-core/include/css/page-builder.css' type='text/css' media='all' />

</head>


<body class="tour-template-default single single-tour postid-4643 gdlr-core-body tourmaster-body woocommerce-no-js traveltour-body traveltour-body-front traveltour-full  traveltour-with-sticky-navigation gdlr-core-link-to-lightbox">
    <div class="traveltour-mobile-header-wrap">
        <div class="traveltour-top-bar">
            <div class="traveltour-top-bar-background"></div>
            <div class="traveltour-top-bar-container clearfix traveltour-top-bar-full ">
                <div class="traveltour-top-bar-left traveltour-item-pdlr travel-tour-hide-on-mobile"><i class="fa fa-phone" style="font-size: 16px ;color: #94999f ;margin-right: 10px ;"></i> 1.820.3345.33
                    <i class="fa fa-envelope-o" style="font-size: 16px ;color: #94999f ;margin-left: 30px ;margin-right: 10px ;"></i> Contact@TravelTourWP.com
                </div>
                <div class="traveltour-top-bar-right traveltour-item-pdlr">
                    <div class="traveltour-top-bar-right-social"><a href="#" target="_blank" class="traveltour-top-bar-social-icon" title="facebook"><i class="fa fa-facebook" ></i></a><a href="#" target="_blank" class="traveltour-top-bar-social-icon" title="flickr"><i class="fa fa-flickr" ></i></a><a href="#" target="_blank" class="traveltour-top-bar-social-icon" title="google-plus"><i class="fa fa-google-plus" ></i></a><a href="#" target="_blank" class="traveltour-top-bar-social-icon" title="twitter"><i class="fa fa-twitter" ></i></a></div>
                    <div class="tourmaster-user-top-bar tourmaster-guest"><a class="tourmaster-user-top-bar-login" href="<?php base_url('login'); ?>"><i class="icon_lock_alt" ></i><span class="tourmaster-text" >Login</span></a><a class="tourmaster-user-top-bar-signup" href="#"><i class="fa fa-user" ></i><span class="tourmaster-text" >Sign Up</span></a></div>
                </div>
            </div>
        </div>
        <div class="traveltour-mobile-header traveltour-header-background traveltour-style-slide" id="traveltour-mobile-header">
            <div class="traveltour-mobile-header-container traveltour-container">
                <div class="traveltour-logo  traveltour-item-pdlr">
                    <div class="traveltour-logo-inner">
                        <a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>mataramweb/upload/logo-v3.png" alt="" width="250" height="52" title="logo-v3" /></a>
                    </div>
                </div>
                <div class="traveltour-mobile-menu-right">
                    <div class="traveltour-main-menu-search" id="traveltour-mobile-top-search"><i class="fa fa-search"></i></div>
                    <div class="traveltour-top-search-wrap">
                        <div class="traveltour-top-search-close"></div>

                        <div class="traveltour-top-search-row">
                            <div class="traveltour-top-search-cell">
                                <form role="search" method="get" class="search-form" action="<?php echo base_url(); ?>">
                                    <input type="text" class="search-field traveltour-title-font" placeholder="Search..." value="" name="s">
                                    <div class="traveltour-top-search-submit"><i class="fa fa-search"></i></div>
                                    <input type="submit" class="search-submit" value="Search">
                                    <div class="traveltour-top-search-close"><i class="icon_close"></i></div>
                                </form>
                            </div>
                        </div>

                    </div>
                    <div class="traveltour-mobile-menu"><a class="traveltour-mm-menu-button traveltour-mobile-menu-button traveltour-mobile-button-hamburger" href="#traveltour-mobile-menu"><span></span></a>
                        <div class="traveltour-mm-menu-wrap traveltour-navigation-font" id="traveltour-mobile-menu" data-slide="right">
                            <ul id="menu-main-navigation" class="m-menu">
                                <li class="menu-item"><a href="<?php echo base_url(); ?>">Home</a></li>
                                <li class="menu-item menu-item-has-children"><a href="<?php echo base_url(); ?>">Pages</a></li>

                                 
                                <li class="menu-item  current-menu-item menu-item-has-children"><a href="<?php echo base_url(); ?>">Tour List</a></li>
                                <li class="menu-item"><a href="">Destinations</a></li>


                                <li class="menu-item menu-item-has-children"><a href="<?php echo base_url(); ?>">Blog</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    

    <div class="traveltour-body-outer-wrapper ">
        <div class="traveltour-body-wrapper clearfix  traveltour-with-frame">
            <div class="traveltour-top-bar traveltour-with-divider">
                <div class="traveltour-top-bar-background"></div>
                <div class="traveltour-top-bar-container clearfix traveltour-top-bar-full ">
                    <div class="traveltour-top-bar-left traveltour-item-pdlr"><i class="fa fa-phone" style="font-size: 16px ;color: #94999f ;margin-right: 10px ;"></i> 1.820.3345.33
                        <i class="fa fa-envelope-o" style="font-size: 16px ;color: #94999f ;margin-left: 30px ;margin-right: 10px ;"></i> Contact@TravelTourWP.com</div>
                    <div class="traveltour-top-bar-right traveltour-item-pdlr">
                        <div class="traveltour-top-bar-right-social"><a href="#" target="_blank" class="traveltour-top-bar-social-icon" title="facebook"><i class="fa fa-facebook" ></i></a><a href="#" target="_blank" class="traveltour-top-bar-social-icon" title="flickr"><i class="fa fa-flickr" ></i></a><a href="#" target="_blank" class="traveltour-top-bar-social-icon" title="google-plus"><i class="fa fa-google-plus" ></i></a><a href="#" target="_blank" class="traveltour-top-bar-social-icon" title="twitter"><i class="fa fa-twitter" ></i></a></div>
                        <div class="tourmaster-user-top-bar tourmaster-guest"><a class="tourmaster-user-top-bar-login" href="<?php base_url('login'); ?>"><i class="icon_lock_alt" ></i><span class="tourmaster-text" >Login</span></a><a class="tourmaster-user-top-bar-signup" href="#"><i class="fa fa-user" ></i><span class="tourmaster-text" >Sign Up</span></a></div>
                    </div>
                </div>
            </div>
            <header class="traveltour-header-wrap traveltour-header-style-plain  traveltour-style-menu-right traveltour-sticky-navigation traveltour-style-fixed">
                <div class="traveltour-header-background"></div>
                <div class="traveltour-header-container  traveltour-container">

                    <div class="traveltour-header-container-inner clearfix">
                        <div class="traveltour-logo  traveltour-item-pdlr">
                            <div class="traveltour-logo-inner">
                                <a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>mataramweb/upload/logo-v3.png" alt="" width="250" height="52" title="logo-v3" /></a>
                            </div>
                        </div>
                        <div class="traveltour-navigation traveltour-item-pdlr clearfix ">
                            <div class="traveltour-main-menu" id="traveltour-main-menu">
                                    <ul id="menu-main-navigation-1" class="sf-menu">
                                        <li class="menu-item traveltour-normal-menu"><a href="<?php echo base_url(); ?>" class="sf-with-ul-pre">Home</a></li>
                                        <li class="menu-item traveltour-normal-menu"><a href="#" class="sf-with-ul-pre">Pages</a> </li>
                                        <li class="menu-item traveltour-normal-menu"><a href="<?php echo base_url('paket'); ?>" class="sf-with-ul-pre">Tour List</a></li>
                                        <li class="menu-item traveltour-normal-menu"><a href="#">Destinations</a></li>
                                        <li class="menu-item traveltour-normal-menu"> <a href="#" class="sf-with-ul-pre">Date &#038; Pricing</a></li>
                                        <li class="menu-item traveltour-normal-menu"><a href="<?php echo base_url('blog'); ?>" class="sf-with-ul-pre">Blog</a></li>
                                    </ul>
                                <div class="traveltour-navigation-slide-bar" id="traveltour-navigation-slide-bar"></div>
                            </div>
                            <div class="traveltour-main-menu-right-wrap clearfix ">
                                <div class="traveltour-main-menu-search" id="traveltour-top-search"><i class="fa fa-search"></i></div>
                                <div class="traveltour-top-search-wrap">
                                    <div class="traveltour-top-search-close"></div>

                                    <div class="traveltour-top-search-row">
                                        <div class="traveltour-top-search-cell">
                                            <form role="search" method="get" class="search-form" action="index.html">
                                                <input type="text" class="search-field traveltour-title-font" placeholder="Search..." value="" name="s">
                                                <div class="traveltour-top-search-submit"><i class="fa fa-search"></i></div>
                                                <input type="submit" class="search-submit" value="Search">
                                                <div class="traveltour-top-search-close"><i class="icon_close"></i></div>
                                            </form>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- traveltour-navigation -->

                    </div>
                    <!-- traveltour-header-inner -->
                    
                </div>
                <!-- traveltour-header-container -->
            </header>
            <!-- header -->