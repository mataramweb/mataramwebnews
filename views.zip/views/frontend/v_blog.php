 <div class="traveltour-page-title-wrap  traveltour-style-custom traveltour-left-align">
                <div class="traveltour-header-transparent-substitute"></div>
                <div class="traveltour-page-title-overlay"></div>
                <div class="traveltour-page-title-container traveltour-container">
                    <div class="traveltour-page-title-content traveltour-item-pdlr">
                        <h1 class="traveltour-page-title">Blog Full Right Sidebar</h1>
                        <div class="traveltour-page-caption">Caption Aligned Here</div>
                    </div>
                </div>
            </div>
            <div class="traveltour-page-wrapper" id="traveltour-page-wrapper">
                <div class="traveltour-content-container traveltour-container">
                    <div class=" traveltour-sidebar-wrap clearfix traveltour-line-height-0 traveltour-sidebar-style-right">
                        <div class=" traveltour-sidebar-center traveltour-column-40 traveltour-line-height">
                            <div class="gdlr-core-page-builder-body">
                                <div class="gdlr-core-pbf-section">
                                    <div class="gdlr-core-pbf-section-container gdlr-core-container clearfix">
                                        <div class="gdlr-core-pbf-element">
                                            <div class="gdlr-core-blog-item gdlr-core-item-pdb clearfix  gdlr-core-style-blog-full" id="div_c50b_0">
                                                <div class="gdlr-core-blog-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                                                   
                                                
                                                
                                                
                                                <?php foreach($artikel as $a){ ?>
                                                
                                                
                                                <div class="gdlr-core-item-list gdlr-core-blog-full  gdlr-core-item-pdlr gdlr-core-style-left">
                                                        <div class="gdlr-core-blog-thumbnail gdlr-core-media-image  gdlr-core-opacity-on-hover gdlr-core-zoom-on-hover">

                                                        <?php if($a->artikel_sampul != ""){ ?>
                                                            <a href="<?php echo base_url().'single/'.$a->artikel_slug; ?>"><img src="<?php echo base_url(); ?>gambar/artikel/<?php echo $a->artikel_sampul ?>" alt="" width="1280" height="580" />
                                                                
                                                            <?php } ?>
                                                            <div class="gdlr-core-sticky-banner gdlr-core-title-font"><i class="fa fa-bolt"></i>Sticky Post</div>
                                                            </a>
                                                        </div>
                                                        <div class="gdlr-core-blog-full-head clearfix">
                                                            <div class="gdlr-core-blog-full-head-right">
                                                                <div class="gdlr-core-blog-info-wrapper gdlr-core-skin-divider">
                                                                  <span class="gdlr-core-blog-info gdlr-core-blog-info-font gdlr-core-skin-caption gdlr-core-blog-info-date">
                                                                    <span class="gdlr-core-head" ><i class="icon_clock_alt" ></i></span>
                                                                    <a href="../2016/06/06/index.html">June 6, 2016</a></span>
                                                                    <span class="gdlr-core-blog-info gdlr-core-blog-info-font gdlr-core-skin-caption gdlr-core-blog-info-author">
                                                                      <span class="gdlr-core-head" ><i class="icon_documents_alt" ></i></span>
                                                                      <a href="#" title="Posts by John Smith" rel="author"><?php echo $a->pengguna_nama ?></a></span>
                                                                      <span class="gdlr-core-blog-info gdlr-core-blog-info-font gdlr-core-skin-caption gdlr-core-blog-info-category">
                                                                        <span class="gdlr-core-head" ><i class="icon_folder-alt" ></i></span>
                                                                        <a href="#" rel="tag">Blog</a><span class="gdlr-core-sep">,</span>
                                                                         <a href="#" rel="tag"><?php echo $a->kategori_nama ?></a></span>
                                                                         <span class="gdlr-core-blog-info gdlr-core-blog-info-font gdlr-core-skin-caption gdlr-core-blog-info-comment-number">
                                                                           <span class="gdlr-core-head" ><i class="icon_comment_alt" ></i></span><a href="../pack-wisely-before-traveling/index.html#respond">5 </a></span>
                                                                </div>
                                                                <h3 class="gdlr-core-blog-title gdlr-core-skin-title" id="h3_c50b_0"><a href="<?php echo base_url().'single/'.$a->artikel_slug; ?>" ><?php echo $a->artikel_judul ?></a></h3></div>
                                                        </div>
                                                        <div class="gdlr-core-blog-content">A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed in the...
                                                            <div class="clear"></div><a class="gdlr-core-excerpt-read-more gdlr-core-button gdlr-core-rectangle" href="../pack-wisely-before-traveling/index.html">Read More</a></div>
                                                    </div>



                                                    <?php } ?>











                                                </div>


                                                <?php echo $this->pagination->create_links(); ?>
  
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>




                        <div class=" traveltour-sidebar-right traveltour-column-20 traveltour-line-height traveltour-line-height">
                            <div class="traveltour-sidebar-area traveltour-item-pdlr">
                                <div id="text-7" class="widget widget_text traveltour-widget">
                                    <h3 class="traveltour-widget-title"><span class="traveltour-widget-head-text">Text Widget</span></h3><span class="clear"></span>
                                    <div class="textwidget">Nulla vitae elit libero, a pharetra augue. Nulla vitae elit libero, a pharetra augue. Nulla vitae elit libero, a pharetra augue. Donec sed odio dui. Etiam porta sem malesuada.</div>
                                </div>

         
      
                                <div id="tag_cloud-3" class="widget widget_tag_cloud traveltour-widget">
                                    <h3 class="traveltour-widget-title"><span class="traveltour-widget-head-text">Tag Cloud</span></h3><span class="clear"></span>
                                    <div class="tagcloud"><a href="../tag/article/index.html" class="tag-cloud-link tag-link-5 tag-link-position-1" id="a_c50b_0" aria-label="Article (1 item)">Article</a> <a href="../tag/building/index.html" class="tag-cloud-link tag-link-6 tag-link-position-2" id="a_c50b_1" aria-label="Building (1 item)">Building</a> <a href="../tag/constructions/index.html" class="tag-cloud-link tag-link-7 tag-link-position-3" id="a_c50b_2" aria-label="Constructions (3 items)">Constructions</a> <a href="../tag/industry/index.html" class="tag-cloud-link tag-link-8 tag-link-position-4" id="a_c50b_3" aria-label="Industry (5 items)">Industry</a> <a href="../tag/metal/index.html" class="tag-cloud-link tag-link-9 tag-link-position-5" id="a_c50b_4" aria-label="Metal (5 items)">Metal</a> <a href="../tag/mining/index.html" class="tag-cloud-link tag-link-10 tag-link-position-6" id="a_c50b_5" aria-label="Mining (3 items)">Mining</a> <a href="../tag/nature/index.html" class="tag-cloud-link tag-link-11 tag-link-position-7" id="a_c50b_6" aria-label="Nature (4 items)">Nature</a> <a href="../tag/news/index.html" class="tag-cloud-link tag-link-12 tag-link-position-8" id="a_c50b_7" aria-label="News (2 items)">News</a> <a href="../tag/oil/index.html" class="tag-cloud-link tag-link-13 tag-link-position-9" id="a_c50b_8" aria-label="Oil (1 item)">Oil</a> <a href="../tag/polymer/index.html" class="tag-cloud-link tag-link-14 tag-link-position-10" id="a_c50b_9" aria-label="Polymer (5 items)">Polymer</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>