		<div class="form-group">
								<label>Kategori</label>
								<select class="form-control" name="kategori">
									<option value="">- Pilih Kategori</option>
									<?php foreach($mahasiswa as $k){ ?>
										<option <?php if($a->nama_jurusan == $k->id_jurusan){echo "selected='selected'";} ?> value="<?php echo $k->id_jurusan ?>"><?php echo $k->nama_jurusan; ?></option>
									<?php } ?>
								</select>
								<br/>

	 </div>
